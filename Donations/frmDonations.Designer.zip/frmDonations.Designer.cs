namespace MCKJ
{
    partial class frmDonations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDonations));
            this.txtReceiptNo = new System.Windows.Forms.TextBox();
            this.uspSELDonationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comDataSet = new MCKJ.ComDataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtReceivedFrom = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtChqG = new System.Windows.Forms.TextBox();
            this.rdbChqG = new System.Windows.Forms.RadioButton();
            this.rdbCashG = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtChqZ = new System.Windows.Forms.TextBox();
            this.rdbChqZ = new System.Windows.Forms.RadioButton();
            this.rdbCashZ = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtChqE = new System.Windows.Forms.TextBox();
            this.rdbChqE = new System.Windows.Forms.RadioButton();
            this.rdbCashE = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.txtNewCard = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtOthers = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTameratiFund = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtEducationFund = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtGeneralFund = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtQabristanFund = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtZakatFund = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPoorFund = new System.Windows.Forms.TextBox();
            this.txtLaagaMrg = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtLaagaEng = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.txtFCardNo = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtHead = new System.Windows.Forms.TextBox();
            this.uspSELFAMILYBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.grbLink = new System.Windows.Forms.GroupBox();
            this.rdbNo = new System.Windows.Forms.RadioButton();
            this.rdbYes = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnView = new System.Windows.Forms.Button();
            this.dgvDonation = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.receiptNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.receivedFromDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.laagaEngDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.laagaMrgDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.poorFundDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.zakatFundDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qabristanFundDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.generalFundDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.educationFundDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tameratiFundDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.newCardDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.othersDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accountRelationDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.fCardNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtFilter = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.usp_SEL_FAMILYTableAdapter = new MCKJ.ComDataSetTableAdapters.usp_SEL_FAMILYTableAdapter();
            this.usp_SEL_DonationTableAdapter = new MCKJ.ComDataSetTableAdapters.usp_SEL_DonationTableAdapter();
            this.tblTransactionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblTransactionsTableAdapter = new MCKJ.ComDataSetTableAdapters.tblTransactionsTableAdapter();
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtOrakh = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.uspSELDonationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uspSELFAMILYBindingSource)).BeginInit();
            this.grbLink.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDonation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblTransactionsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txtReceiptNo
            // 
            this.txtReceiptNo.BackColor = System.Drawing.Color.White;
            this.txtReceiptNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "ReceiptNo", true));
            this.txtReceiptNo.Location = new System.Drawing.Point(97, 72);
            this.txtReceiptNo.Name = "txtReceiptNo";
            this.txtReceiptNo.Size = new System.Drawing.Size(73, 20);
            this.txtReceiptNo.TabIndex = 8;
            this.txtReceiptNo.Leave += new System.EventHandler(this.txtReceiptNo_Leave);
            // 
            // uspSELDonationBindingSource
            // 
            this.uspSELDonationBindingSource.DataMember = "usp_SEL_Donation";
            this.uspSELDonationBindingSource.DataSource = this.comDataSet;
            // 
            // comDataSet
            // 
            this.comDataSet.DataSetName = "ComDataSet";
            this.comDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Receipt No:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(392, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Date:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Received From:";
            // 
            // txtReceivedFrom
            // 
            this.txtReceivedFrom.BackColor = System.Drawing.Color.White;
            this.txtReceivedFrom.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "ReceivedFrom", true));
            this.txtReceivedFrom.Location = new System.Drawing.Point(97, 151);
            this.txtReceivedFrom.Name = "txtReceivedFrom";
            this.txtReceivedFrom.Size = new System.Drawing.Size(136, 20);
            this.txtReceivedFrom.TabIndex = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtNewCard);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtOthers);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtTameratiFund);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtEducationFund);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtGeneralFund);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtQabristanFund);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtZakatFund);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtPoorFund);
            this.groupBox1.Controls.Add(this.txtLaagaMrg);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtLaagaEng);
            this.groupBox1.Location = new System.Drawing.Point(12, 186);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(515, 238);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "On Account Of";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtChqG);
            this.groupBox4.Controls.Add(this.rdbChqG);
            this.groupBox4.Controls.Add(this.rdbCashG);
            this.groupBox4.Location = new System.Drawing.Point(242, 167);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(217, 30);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            // 
            // txtChqG
            // 
            this.txtChqG.BackColor = System.Drawing.Color.White;
            this.txtChqG.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "GNo", true));
            this.txtChqG.Enabled = false;
            this.txtChqG.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChqG.Location = new System.Drawing.Point(122, 9);
            this.txtChqG.Name = "txtChqG";
            this.txtChqG.Size = new System.Drawing.Size(83, 18);
            this.txtChqG.TabIndex = 2;
            // 
            // rdbChqG
            // 
            this.rdbChqG.AutoSize = true;
            this.rdbChqG.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbChqG.Location = new System.Drawing.Point(61, 11);
            this.rdbChqG.Name = "rdbChqG";
            this.rdbChqG.Size = new System.Drawing.Size(55, 16);
            this.rdbChqG.TabIndex = 1;
            this.rdbChqG.Text = "Cheque";
            this.rdbChqG.UseVisualStyleBackColor = true;
            // 
            // rdbCashG
            // 
            this.rdbCashG.AutoSize = true;
            this.rdbCashG.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.uspSELDonationBindingSource, "TypeG", true));
            this.rdbCashG.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCashG.Location = new System.Drawing.Point(6, 11);
            this.rdbCashG.Name = "rdbCashG";
            this.rdbCashG.Size = new System.Drawing.Size(45, 16);
            this.rdbCashG.TabIndex = 0;
            this.rdbCashG.Text = "Cash";
            this.rdbCashG.UseVisualStyleBackColor = true;
            this.rdbCashG.CheckedChanged += new System.EventHandler(this.rdbCashG_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtChqZ);
            this.groupBox3.Controls.Add(this.rdbChqZ);
            this.groupBox3.Controls.Add(this.rdbCashZ);
            this.groupBox3.Location = new System.Drawing.Point(242, 131);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(217, 30);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            // 
            // txtChqZ
            // 
            this.txtChqZ.BackColor = System.Drawing.Color.White;
            this.txtChqZ.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "ZNo", true));
            this.txtChqZ.Enabled = false;
            this.txtChqZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChqZ.Location = new System.Drawing.Point(122, 9);
            this.txtChqZ.Name = "txtChqZ";
            this.txtChqZ.Size = new System.Drawing.Size(83, 18);
            this.txtChqZ.TabIndex = 1;
            // 
            // rdbChqZ
            // 
            this.rdbChqZ.AutoSize = true;
            this.rdbChqZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbChqZ.Location = new System.Drawing.Point(61, 11);
            this.rdbChqZ.Name = "rdbChqZ";
            this.rdbChqZ.Size = new System.Drawing.Size(55, 16);
            this.rdbChqZ.TabIndex = 0;
            this.rdbChqZ.Text = "Cheque";
            this.rdbChqZ.UseVisualStyleBackColor = true;
            // 
            // rdbCashZ
            // 
            this.rdbCashZ.AutoSize = true;
            this.rdbCashZ.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.uspSELDonationBindingSource, "TypeZ", true));
            this.rdbCashZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCashZ.Location = new System.Drawing.Point(6, 11);
            this.rdbCashZ.Name = "rdbCashZ";
            this.rdbCashZ.Size = new System.Drawing.Size(45, 16);
            this.rdbCashZ.TabIndex = 2;
            this.rdbCashZ.Text = "Cash";
            this.rdbCashZ.UseVisualStyleBackColor = true;
            this.rdbCashZ.CheckedChanged += new System.EventHandler(this.rdbCashZ_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtChqE);
            this.groupBox2.Controls.Add(this.rdbChqE);
            this.groupBox2.Controls.Add(this.rdbCashE);
            this.groupBox2.Location = new System.Drawing.Point(240, 95);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(217, 30);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            // 
            // txtChqE
            // 
            this.txtChqE.BackColor = System.Drawing.Color.White;
            this.txtChqE.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "ENo", true));
            this.txtChqE.Enabled = false;
            this.txtChqE.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChqE.Location = new System.Drawing.Point(122, 9);
            this.txtChqE.Name = "txtChqE";
            this.txtChqE.Size = new System.Drawing.Size(83, 18);
            this.txtChqE.TabIndex = 2;
            // 
            // rdbChqE
            // 
            this.rdbChqE.AutoSize = true;
            this.rdbChqE.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbChqE.Location = new System.Drawing.Point(61, 11);
            this.rdbChqE.Name = "rdbChqE";
            this.rdbChqE.Size = new System.Drawing.Size(55, 16);
            this.rdbChqE.TabIndex = 1;
            this.rdbChqE.Text = "Cheque";
            this.rdbChqE.UseVisualStyleBackColor = true;
            // 
            // rdbCashE
            // 
            this.rdbCashE.AutoSize = true;
            this.rdbCashE.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.uspSELDonationBindingSource, "TypeE", true));
            this.rdbCashE.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCashE.Location = new System.Drawing.Point(6, 11);
            this.rdbCashE.Name = "rdbCashE";
            this.rdbCashE.Size = new System.Drawing.Size(45, 16);
            this.rdbCashE.TabIndex = 0;
            this.rdbCashE.Text = "Cash";
            this.rdbCashE.UseVisualStyleBackColor = true;
            this.rdbCashE.CheckedChanged += new System.EventHandler(this.rdbCashE_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(239, 78);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "New Family Card";
            // 
            // txtNewCard
            // 
            this.txtNewCard.BackColor = System.Drawing.Color.White;
            this.txtNewCard.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "NewCard", true));
            this.txtNewCard.Location = new System.Drawing.Point(326, 75);
            this.txtNewCard.Name = "txtNewCard";
            this.txtNewCard.Size = new System.Drawing.Size(100, 20);
            this.txtNewCard.TabIndex = 5;
            this.txtNewCard.Text = "0.00";
            this.txtNewCard.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNewCard.TextChanged += new System.EventHandler(this.txtNewCard_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 205);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "Others";
            // 
            // txtOthers
            // 
            this.txtOthers.BackColor = System.Drawing.Color.White;
            this.txtOthers.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "Others", true));
            this.txtOthers.Location = new System.Drawing.Point(121, 202);
            this.txtOthers.Name = "txtOthers";
            this.txtOthers.Size = new System.Drawing.Size(100, 20);
            this.txtOthers.TabIndex = 14;
            this.txtOthers.Text = "0.00";
            this.txtOthers.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOthers.TextChanged += new System.EventHandler(this.txtOthers_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 78);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "Tamerati Fund";
            // 
            // txtTameratiFund
            // 
            this.txtTameratiFund.BackColor = System.Drawing.Color.White;
            this.txtTameratiFund.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "TameratiFund", true));
            this.txtTameratiFund.Location = new System.Drawing.Point(121, 75);
            this.txtTameratiFund.Name = "txtTameratiFund";
            this.txtTameratiFund.Size = new System.Drawing.Size(100, 20);
            this.txtTameratiFund.TabIndex = 4;
            this.txtTameratiFund.Text = "0.00";
            this.txtTameratiFund.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTameratiFund.TextChanged += new System.EventHandler(this.txtTameratiFund_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 107);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Education Fund";
            // 
            // txtEducationFund
            // 
            this.txtEducationFund.BackColor = System.Drawing.Color.White;
            this.txtEducationFund.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "EducationFund", true));
            this.txtEducationFund.Location = new System.Drawing.Point(121, 104);
            this.txtEducationFund.Name = "txtEducationFund";
            this.txtEducationFund.Size = new System.Drawing.Size(100, 20);
            this.txtEducationFund.TabIndex = 6;
            this.txtEducationFund.Text = "0.00";
            this.txtEducationFund.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEducationFund.TextChanged += new System.EventHandler(this.txtEducationFund_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 179);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "General Donation";
            // 
            // txtGeneralFund
            // 
            this.txtGeneralFund.BackColor = System.Drawing.Color.White;
            this.txtGeneralFund.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "GeneralFund", true));
            this.txtGeneralFund.Location = new System.Drawing.Point(121, 176);
            this.txtGeneralFund.Name = "txtGeneralFund";
            this.txtGeneralFund.Size = new System.Drawing.Size(100, 20);
            this.txtGeneralFund.TabIndex = 10;
            this.txtGeneralFund.Text = "0.00";
            this.txtGeneralFund.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtGeneralFund.TextChanged += new System.EventHandler(this.txtGeneralFund_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(239, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Qabristab Fund";
            // 
            // txtQabristanFund
            // 
            this.txtQabristanFund.BackColor = System.Drawing.Color.White;
            this.txtQabristanFund.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "QabristanFund", true));
            this.txtQabristanFund.Location = new System.Drawing.Point(326, 49);
            this.txtQabristanFund.Name = "txtQabristanFund";
            this.txtQabristanFund.Size = new System.Drawing.Size(100, 20);
            this.txtQabristanFund.TabIndex = 3;
            this.txtQabristanFund.Text = "0.00";
            this.txtQabristanFund.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQabristanFund.TextChanged += new System.EventHandler(this.txtQabristanFund_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Zakat Fund";
            // 
            // txtZakatFund
            // 
            this.txtZakatFund.BackColor = System.Drawing.Color.White;
            this.txtZakatFund.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "ZakatFund", true));
            this.txtZakatFund.Location = new System.Drawing.Point(121, 138);
            this.txtZakatFund.Name = "txtZakatFund";
            this.txtZakatFund.Size = new System.Drawing.Size(100, 20);
            this.txtZakatFund.TabIndex = 8;
            this.txtZakatFund.Text = "0.00";
            this.txtZakatFund.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtZakatFund.TextChanged += new System.EventHandler(this.txtZakatFund_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Poor Fund";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(239, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Laaga Marriage";
            // 
            // txtPoorFund
            // 
            this.txtPoorFund.BackColor = System.Drawing.Color.White;
            this.txtPoorFund.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "PoorFund", true));
            this.txtPoorFund.Location = new System.Drawing.Point(121, 49);
            this.txtPoorFund.Name = "txtPoorFund";
            this.txtPoorFund.Size = new System.Drawing.Size(100, 20);
            this.txtPoorFund.TabIndex = 2;
            this.txtPoorFund.Text = "0.00";
            this.txtPoorFund.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPoorFund.TextChanged += new System.EventHandler(this.txtPoorFund_TextChanged);
            // 
            // txtLaagaMrg
            // 
            this.txtLaagaMrg.BackColor = System.Drawing.Color.White;
            this.txtLaagaMrg.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "LaagaMrg", true));
            this.txtLaagaMrg.Location = new System.Drawing.Point(326, 23);
            this.txtLaagaMrg.Name = "txtLaagaMrg";
            this.txtLaagaMrg.Size = new System.Drawing.Size(100, 20);
            this.txtLaagaMrg.TabIndex = 1;
            this.txtLaagaMrg.Text = "0.00";
            this.txtLaagaMrg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLaagaMrg.TextChanged += new System.EventHandler(this.txtLaagaMrg_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Laaga Engagement";
            // 
            // txtLaagaEng
            // 
            this.txtLaagaEng.BackColor = System.Drawing.Color.White;
            this.txtLaagaEng.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "LaagaEng", true));
            this.txtLaagaEng.Location = new System.Drawing.Point(121, 23);
            this.txtLaagaEng.Name = "txtLaagaEng";
            this.txtLaagaEng.Size = new System.Drawing.Size(100, 20);
            this.txtLaagaEng.TabIndex = 0;
            this.txtLaagaEng.Text = "0.00";
            this.txtLaagaEng.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLaagaEng.TextChanged += new System.EventHandler(this.txtLaagaEng_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.Control;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(347, 441);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 13);
            this.label14.TabIndex = 28;
            this.label14.Text = "Total";
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.Color.White;
            this.txtTotal.Location = new System.Drawing.Point(405, 438);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.TabIndex = 7;
            this.txtTotal.TabStop = false;
            this.txtTotal.Text = "0.00";
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dtpDate
            // 
            this.dtpDate.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "Date", true));
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDate.Location = new System.Drawing.Point(443, 72);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(84, 20);
            this.dtpDate.TabIndex = 8;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 101);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 13);
            this.label15.TabIndex = 31;
            this.label15.Text = "Family Card No";
            // 
            // txtFCardNo
            // 
            this.txtFCardNo.BackColor = System.Drawing.Color.White;
            this.txtFCardNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "FCardNo", true));
            this.txtFCardNo.Location = new System.Drawing.Point(97, 98);
            this.txtFCardNo.Name = "txtFCardNo";
            this.txtFCardNo.Size = new System.Drawing.Size(73, 20);
            this.txtFCardNo.TabIndex = 9;
            this.txtFCardNo.Leave += new System.EventHandler(this.txtFCardNo_Leave);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 129);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 13);
            this.label16.TabIndex = 33;
            this.label16.Text = "Head of Family";
            // 
            // txtHead
            // 
            this.txtHead.BackColor = System.Drawing.Color.White;
            this.txtHead.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELFAMILYBindingSource, "FamilyLeader", true));
            this.txtHead.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHead.ForeColor = System.Drawing.Color.Black;
            this.txtHead.Location = new System.Drawing.Point(97, 124);
            this.txtHead.Name = "txtHead";
            this.txtHead.ReadOnly = true;
            this.txtHead.Size = new System.Drawing.Size(96, 21);
            this.txtHead.TabIndex = 5;
            this.txtHead.TabStop = false;
            // 
            // uspSELFAMILYBindingSource
            // 
            this.uspSELFAMILYBindingSource.DataMember = "usp_SEL_FAMILY";
            this.uspSELFAMILYBindingSource.DataSource = this.comDataSet;
            // 
            // grbLink
            // 
            this.grbLink.Controls.Add(this.rdbNo);
            this.grbLink.Controls.Add(this.rdbYes);
            this.grbLink.Location = new System.Drawing.Point(382, 119);
            this.grbLink.Name = "grbLink";
            this.grbLink.Size = new System.Drawing.Size(145, 52);
            this.grbLink.TabIndex = 12;
            this.grbLink.TabStop = false;
            this.grbLink.Text = "Account Relation";
            // 
            // rdbNo
            // 
            this.rdbNo.AutoSize = true;
            this.rdbNo.Location = new System.Drawing.Point(85, 23);
            this.rdbNo.Name = "rdbNo";
            this.rdbNo.Size = new System.Drawing.Size(39, 17);
            this.rdbNo.TabIndex = 1;
            this.rdbNo.Text = "No";
            this.rdbNo.UseVisualStyleBackColor = true;
            // 
            // rdbYes
            // 
            this.rdbYes.AutoSize = true;
            this.rdbYes.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.uspSELDonationBindingSource, "AccountRelation", true));
            this.rdbYes.Location = new System.Drawing.Point(18, 23);
            this.rdbYes.Name = "rdbYes";
            this.rdbYes.Size = new System.Drawing.Size(43, 17);
            this.rdbYes.TabIndex = 0;
            this.rdbYes.Text = "Yes";
            this.rdbYes.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(12, 430);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(515, 37);
            this.pictureBox1.TabIndex = 275;
            this.pictureBox1.TabStop = false;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(173, 512);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(12, 473);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 10;
            this.btnReset.TabStop = false;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(452, 473);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(92, 512);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 3;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(371, 473);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(11, 512);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "New";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(463, 550);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 14;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnView
            // 
            this.btnView.Location = new System.Drawing.Point(463, 512);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(75, 23);
            this.btnView.TabIndex = 6;
            this.btnView.Text = "View";
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // dgvDonation
            // 
            this.dgvDonation.AllowUserToAddRows = false;
            this.dgvDonation.AllowUserToDeleteRows = false;
            this.dgvDonation.AutoGenerateColumns = false;
            this.dgvDonation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDonation.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.receiptNoDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.receivedFromDataGridViewTextBoxColumn,
            this.laagaEngDataGridViewTextBoxColumn,
            this.laagaMrgDataGridViewTextBoxColumn,
            this.poorFundDataGridViewTextBoxColumn,
            this.zakatFundDataGridViewTextBoxColumn,
            this.qabristanFundDataGridViewTextBoxColumn,
            this.generalFundDataGridViewTextBoxColumn,
            this.educationFundDataGridViewTextBoxColumn,
            this.tameratiFundDataGridViewTextBoxColumn,
            this.newCardDataGridViewTextBoxColumn,
            this.othersDataGridViewTextBoxColumn,
            this.accountRelationDataGridViewCheckBoxColumn,
            this.fCardNoDataGridViewTextBoxColumn});
            this.dgvDonation.DataSource = this.uspSELDonationBindingSource;
            this.dgvDonation.Location = new System.Drawing.Point(10, 66);
            this.dgvDonation.Name = "dgvDonation";
            this.dgvDonation.ReadOnly = true;
            this.dgvDonation.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDonation.Size = new System.Drawing.Size(523, 430);
            this.dgvDonation.TabIndex = 2;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn.Visible = false;
            // 
            // receiptNoDataGridViewTextBoxColumn
            // 
            this.receiptNoDataGridViewTextBoxColumn.DataPropertyName = "ReceiptNo";
            this.receiptNoDataGridViewTextBoxColumn.HeaderText = "ReceiptNo";
            this.receiptNoDataGridViewTextBoxColumn.Name = "receiptNoDataGridViewTextBoxColumn";
            this.receiptNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // receivedFromDataGridViewTextBoxColumn
            // 
            this.receivedFromDataGridViewTextBoxColumn.DataPropertyName = "ReceivedFrom";
            this.receivedFromDataGridViewTextBoxColumn.HeaderText = "ReceivedFrom";
            this.receivedFromDataGridViewTextBoxColumn.Name = "receivedFromDataGridViewTextBoxColumn";
            this.receivedFromDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // laagaEngDataGridViewTextBoxColumn
            // 
            this.laagaEngDataGridViewTextBoxColumn.DataPropertyName = "LaagaEng";
            this.laagaEngDataGridViewTextBoxColumn.HeaderText = "LaagaEng";
            this.laagaEngDataGridViewTextBoxColumn.Name = "laagaEngDataGridViewTextBoxColumn";
            this.laagaEngDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // laagaMrgDataGridViewTextBoxColumn
            // 
            this.laagaMrgDataGridViewTextBoxColumn.DataPropertyName = "LaagaMrg";
            this.laagaMrgDataGridViewTextBoxColumn.HeaderText = "LaagaMrg";
            this.laagaMrgDataGridViewTextBoxColumn.Name = "laagaMrgDataGridViewTextBoxColumn";
            this.laagaMrgDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // poorFundDataGridViewTextBoxColumn
            // 
            this.poorFundDataGridViewTextBoxColumn.DataPropertyName = "PoorFund";
            this.poorFundDataGridViewTextBoxColumn.HeaderText = "PoorFund";
            this.poorFundDataGridViewTextBoxColumn.Name = "poorFundDataGridViewTextBoxColumn";
            this.poorFundDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // zakatFundDataGridViewTextBoxColumn
            // 
            this.zakatFundDataGridViewTextBoxColumn.DataPropertyName = "ZakatFund";
            this.zakatFundDataGridViewTextBoxColumn.HeaderText = "ZakatFund";
            this.zakatFundDataGridViewTextBoxColumn.Name = "zakatFundDataGridViewTextBoxColumn";
            this.zakatFundDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // qabristanFundDataGridViewTextBoxColumn
            // 
            this.qabristanFundDataGridViewTextBoxColumn.DataPropertyName = "QabristanFund";
            this.qabristanFundDataGridViewTextBoxColumn.HeaderText = "QabristanFund";
            this.qabristanFundDataGridViewTextBoxColumn.Name = "qabristanFundDataGridViewTextBoxColumn";
            this.qabristanFundDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // generalFundDataGridViewTextBoxColumn
            // 
            this.generalFundDataGridViewTextBoxColumn.DataPropertyName = "GeneralFund";
            this.generalFundDataGridViewTextBoxColumn.HeaderText = "GeneralFund";
            this.generalFundDataGridViewTextBoxColumn.Name = "generalFundDataGridViewTextBoxColumn";
            this.generalFundDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // educationFundDataGridViewTextBoxColumn
            // 
            this.educationFundDataGridViewTextBoxColumn.DataPropertyName = "EducationFund";
            this.educationFundDataGridViewTextBoxColumn.HeaderText = "EducationFund";
            this.educationFundDataGridViewTextBoxColumn.Name = "educationFundDataGridViewTextBoxColumn";
            this.educationFundDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tameratiFundDataGridViewTextBoxColumn
            // 
            this.tameratiFundDataGridViewTextBoxColumn.DataPropertyName = "TameratiFund";
            this.tameratiFundDataGridViewTextBoxColumn.HeaderText = "TameratiFund";
            this.tameratiFundDataGridViewTextBoxColumn.Name = "tameratiFundDataGridViewTextBoxColumn";
            this.tameratiFundDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // newCardDataGridViewTextBoxColumn
            // 
            this.newCardDataGridViewTextBoxColumn.DataPropertyName = "NewCard";
            this.newCardDataGridViewTextBoxColumn.HeaderText = "NewCard";
            this.newCardDataGridViewTextBoxColumn.Name = "newCardDataGridViewTextBoxColumn";
            this.newCardDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // othersDataGridViewTextBoxColumn
            // 
            this.othersDataGridViewTextBoxColumn.DataPropertyName = "Others";
            this.othersDataGridViewTextBoxColumn.HeaderText = "Others";
            this.othersDataGridViewTextBoxColumn.Name = "othersDataGridViewTextBoxColumn";
            this.othersDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // accountRelationDataGridViewCheckBoxColumn
            // 
            this.accountRelationDataGridViewCheckBoxColumn.DataPropertyName = "AccountRelation";
            this.accountRelationDataGridViewCheckBoxColumn.HeaderText = "AccountRelation";
            this.accountRelationDataGridViewCheckBoxColumn.Name = "accountRelationDataGridViewCheckBoxColumn";
            this.accountRelationDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // fCardNoDataGridViewTextBoxColumn
            // 
            this.fCardNoDataGridViewTextBoxColumn.DataPropertyName = "FCardNo";
            this.fCardNoDataGridViewTextBoxColumn.HeaderText = "FCardNo";
            this.fCardNoDataGridViewTextBoxColumn.Name = "fCardNoDataGridViewTextBoxColumn";
            this.fCardNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // txtFilter
            // 
            this.txtFilter.Location = new System.Drawing.Point(80, 38);
            this.txtFilter.Name = "txtFilter";
            this.txtFilter.Size = new System.Drawing.Size(100, 20);
            this.txtFilter.TabIndex = 0;
            this.txtFilter.TextChanged += new System.EventHandler(this.txtFilter_TextChanged);
            this.txtFilter.Leave += new System.EventHandler(this.txtFilter_Leave);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(10, 41);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 13);
            this.label18.TabIndex = 287;
            this.label18.Text = "Receipt No:";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(186, 36);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(382, 512);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 5;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // usp_SEL_FAMILYTableAdapter
            // 
            this.usp_SEL_FAMILYTableAdapter.ClearBeforeFill = true;
            // 
            // usp_SEL_DonationTableAdapter
            // 
            this.usp_SEL_DonationTableAdapter.ClearBeforeFill = true;
            // 
            // tblTransactionsBindingSource
            // 
            this.tblTransactionsBindingSource.DataMember = "tblTransactions";
            this.tblTransactionsBindingSource.DataSource = this.comDataSet;
            // 
            // tblTransactionsTableAdapter
            // 
            this.tblTransactionsTableAdapter.ClearBeforeFill = true;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label38.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.Black;
            this.label38.Location = new System.Drawing.Point(1, -1);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(556, 19);
            this.label38.TabIndex = 384;
            this.label38.Text = "Donations";
            //this.label38.Click += new System.EventHandler(this.label38_Click);
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label40.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.Transparent;
            this.label40.Location = new System.Drawing.Point(12, 66);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(515, 1);
            this.label40.TabIndex = 386;
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(176, 101);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(36, 13);
            this.label19.TabIndex = 388;
            this.label19.Text = "Orakh";
            // 
            // txtOrakh
            // 
            this.txtOrakh.BackColor = System.Drawing.Color.White;
            this.txtOrakh.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELFAMILYBindingSource, "Sign", true));
            this.txtOrakh.Location = new System.Drawing.Point(218, 98);
            this.txtOrakh.Name = "txtOrakh";
            this.txtOrakh.Size = new System.Drawing.Size(83, 20);
            this.txtOrakh.TabIndex = 387;
            this.txtOrakh.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(199, 129);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(71, 13);
            this.label20.TabIndex = 390;
            this.label20.Text = "Father Name:";
            // 
            // txtFName
            // 
            this.txtFName.BackColor = System.Drawing.Color.White;
            this.txtFName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uspSELDonationBindingSource, "FName", true));
            this.txtFName.Location = new System.Drawing.Point(276, 126);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(92, 20);
            this.txtFName.TabIndex = 389;
            this.txtFName.TabStop = false;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Transparent;
            this.label17.Location = new System.Drawing.Point(18, 543);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(515, 1);
            this.label17.TabIndex = 391;
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmDonations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(551, 586);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtFName);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtOrakh);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtFilter);
            this.Controls.Add(this.btnView);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.grbLink);
            this.Controls.Add(this.txtReceivedFrom);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtFCardNo);
            this.Controls.Add(this.txtHead);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtReceiptNo);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dgvDonation);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDonations";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Musalman Cutchi Khatri Jamat";
            this.Load += new System.EventHandler(this.frmDonations_Load);
            ((System.ComponentModel.ISupportInitialize)(this.uspSELDonationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uspSELFAMILYBindingSource)).EndInit();
            this.grbLink.ResumeLayout(false);
            this.grbLink.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDonation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblTransactionsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtReceiptNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtReceivedFrom;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNewCard;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtOthers;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtTameratiFund;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtEducationFund;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtGeneralFund;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtQabristanFund;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtZakatFund;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPoorFund;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtLaagaMrg;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtLaagaEng;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtFCardNo;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtHead;
        private ComDataSet comDataSet;
        private System.Windows.Forms.BindingSource uspSELFAMILYBindingSource;
        private MCKJ.ComDataSetTableAdapters.usp_SEL_FAMILYTableAdapter usp_SEL_FAMILYTableAdapter;
        private System.Windows.Forms.BindingSource uspSELDonationBindingSource;
        private MCKJ.ComDataSetTableAdapters.usp_SEL_DonationTableAdapter usp_SEL_DonationTableAdapter;
        private System.Windows.Forms.GroupBox grbLink;
        private System.Windows.Forms.RadioButton rdbNo;
        private System.Windows.Forms.RadioButton rdbYes;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.DataGridView dgvDonation;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn receiptNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn receivedFromDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn laagaEngDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn laagaMrgDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn poorFundDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn zakatFundDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qabristanFundDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn generalFundDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn educationFundDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tameratiFundDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn newCardDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn othersDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn accountRelationDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fCardNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox txtFilter;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.BindingSource tblTransactionsBindingSource;
        private MCKJ.ComDataSetTableAdapters.tblTransactionsTableAdapter tblTransactionsTableAdapter;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtOrakh;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtChqE;
        private System.Windows.Forms.RadioButton rdbChqE;
        private System.Windows.Forms.RadioButton rdbCashE;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtChqG;
        private System.Windows.Forms.RadioButton rdbChqG;
        private System.Windows.Forms.RadioButton rdbCashG;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtChqZ;
        private System.Windows.Forms.RadioButton rdbChqZ;
        private System.Windows.Forms.RadioButton rdbCashZ;
    }
}