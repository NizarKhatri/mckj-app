using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MCKJ
{
    public partial class frmTransactions : Form
    {
        //Community.DBLayer dbLayer = new Community.DBLayer();

        int mode = 0;
        int currRowIndex = 0;
        int initialTop = 86;
        int exit = 0;
        int UserID = Community.DBLayer.ID;
        int SecurityLevelID = 12;
        Community.DBLayer DBLayer = new Community.DBLayer();
        string con_String = @"Data Source=(local);Initial Catalog=Community;Integrated Security=True";
        
        #region Functions   

            private void fillGrid()
            {

                SqlConnection Conn = new SqlConnection(Community.DBLayer.con_String);

                try
                {
                    Conn.Open();

                    SqlCommand Command = new SqlCommand("SELECT Distinct Voucher, DocumentNo, Dated FROM tblTransactions Order By DocumentNo DESC", Conn);

                    SqlDataReader Reader = Command.ExecuteReader();

                    if (Reader.HasRows)
                    {
                        if (dgvVouchers.RowCount != 0)
                        {
                            dgvVouchers.Rows.Clear();
                        }

                        while (Reader.Read())
                        {
                            int z = dgvVouchers.Rows.Add();

                            string voucher = Reader.GetValue(0).ToString() + "-" + Convert.ToDecimal(Reader.GetValue(1).ToString()).ToString("00000");
                            DateTime dated = Convert.ToDateTime(Reader.GetValue(2).ToString());

                            dgvVouchers.Rows[z].Cells[0].Value = voucher;
                            dgvVouchers.Rows[z].Cells[1].Value = dated.ToShortDateString();

                        }
                    }

                    Reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                finally
                {
                    if (Conn.State != ConnectionState.Closed || Conn.State != ConnectionState.Broken)
                    {
                        Conn.Close();
                    }

                }
            }
            private int getNextSerialNo()
            {
                int next = 1;

                SqlConnection Conn = new SqlConnection(con_String);

                try
                {
                    Conn.Open();

                    SqlCommand Command = new SqlCommand("Select DocumentNo From tblTransactions Order By ID DESC",Conn);

                    SqlDataReader Reader = Command.ExecuteReader();

                    if(Reader.HasRows)
                    {
                        Reader.Read();

                        next = Convert.ToInt32(Reader.GetValue(0).ToString())+1;
                    }

                    Reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error" , MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                }
                finally
                {
                    if (Conn.State != ConnectionState.Closed || Conn.State != ConnectionState.Broken)
                    {
                        Conn.Close();
                    }

                }

                return next;
            }        
            
            private bool checkDocumentNo(int DocumentNo, string Voucher)
            {
                if (DocumentNo == 0 || Voucher == "")
                {
                    return false;
                }
                else
                {
                    bool result = false;
                    
                    SqlConnection Conn = new SqlConnection(con_String);

                    try
                    {
                        Conn.Open();

                        SqlCommand Command = new SqlCommand("Select DocumentNo From tblTransactions Where Voucher='" + Voucher + "' AND DocumentNo=" + DocumentNo.ToString(), Conn);

                        SqlDataReader Reader = Command.ExecuteReader();

                        if(Reader.HasRows)
                        {
                            Reader.Read();

                            result = true;
                        }

                        Reader.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error" , MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                    }
                    finally
                    {
                        if (Conn.State != ConnectionState.Closed || Conn.State != ConnectionState.Broken)
                        {
                            Conn.Close();
                        }

                    }

                    return result;
                }
            }

            private bool validateAmount()
            {
                bool result = true;

                try
                {
                if(dgvTransactions.RowCount==0)
                {
                    result = false;
                }
                else if (dgvTransactions.RowCount < 3)
                {
                    result = false;
                    MessageBox.Show("Please enter atleast 2 transactions!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    double Debit = 0;
                    double Credit = 0;

                    for (int x = 0; x < dgvTransactions.RowCount - 1; x++)
                    {
                        if (dgvTransactions.Rows[x].Cells[4].Value != null)
                        {
                            Debit += Convert.ToDouble(dgvTransactions.Rows[x].Cells[4].Value.ToString());
                        }
                        else
                        {
                            if (dgvTransactions.Rows[x].Cells[5].Value == null)
                            {
                                result = false;
                                break;
                            }                            
                        }

                        if (dgvTransactions.Rows[x].Cells[5].Value != null)
                        {
                            Credit += Convert.ToDouble(dgvTransactions.Rows[x].Cells[5].Value.ToString());
                        }
                        else
                        {
                            if (dgvTransactions.Rows[x].Cells[4].Value == null)
                            {
                                result = false;
                                break;
                            }
                        }
                    }

                    if (Debit == 0 && Credit == 0)
                    {
                        result = false;
                    }

                    if (Debit != Credit)
                    {
                        result = false;
                                                
                    }

                    if (!result)
                    {
                        MessageBox.Show("Debit and Credit must be equal and non-zero!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                }
                catch(FormatException)
                {
                    MessageBox.Show("Please enter valid numeric values!", "Error" , MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                    result = false;
                }

                return result;
            }
            
            private bool validateFields()
            {
                bool result = true;
                bool docResult = false;
                //Check Header First!

                for (int x = 0; x < dgvTransactions.Rows.Count - 1; x++)
                {
                    if (dgvTransactions.Rows[x].Cells[0].Value == null)
                    {
                        int y = x + 1;
                        MessageBox.Show("Please select party in Row " + y, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        return false;
                    }
                    
                }

                if (txtDocumentNo.Text == "")
                {

                    MessageBox.Show("Please enter Document No!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                    return false;
                }
               
                return validateAmount();

            }

            private string[] getVoucherByDate(DateTime Date)
            {
                string[] voucher = new string[2];

                SqlConnection Conn = new SqlConnection(con_String);

                try
                {
                    Conn.Open();

                    SqlCommand Command = new SqlCommand("Select Voucher,DocumentNo From tblTransactions Where Dated='" + Date.ToString("M/d/yyyy") + "'", Conn);

                    SqlDataReader Reader = Command.ExecuteReader();

                    if (Reader.HasRows)
                    {
                        Reader.Read();

                        voucher[0] = Reader.GetValue(0).ToString();
                        voucher[1] = Reader.GetValue(1).ToString();
                    }

                    Reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                finally
                {
                    if (Conn.State != ConnectionState.Closed || Conn.State != ConnectionState.Broken)
                    {
                        Conn.Close();
                    }

                }

                return voucher;
            }        

        #endregion

        public frmTransactions()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTransactions.Rows.Count != 0)
                {
                    mode = 0;
                    txtDocumentNo.Text = getNextSerialNo().ToString("00000");
                    dgvTransactions.Rows.Clear();
                    dgvTransactions.SelectionMode = DataGridViewSelectionMode.RowHeaderSelect;
                }
                else
                {
                    MessageBox.Show("No row(s) to remove!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (validateFields())
                {
                    string Voucher = cmbVoucherType.SelectedValue.ToString();
                    int DocumentNo = Convert.ToInt32(txtDocumentNo.Text);

                    DateTime Date = Convert.ToDateTime(dtpDate.Text);

                    int rSuccess = 0;
                    int rAdded = 0;

                    if (mode == 0)
                    {
                        if (!checkDocumentNo(DocumentNo,Voucher))
                        {
                            for (int x = 0; x < dgvTransactions.RowCount - 1; x++)
                            {
                                int AccountCode = Convert.ToInt32(dgvTransactions.Rows[x].Cells[0].Value.ToString());

                                string Narration = "";                                
                                if (dgvTransactions.Rows[x].Cells[1].Value != null)
                                {
                                    Narration = dgvTransactions.Rows[x].Cells[1].Value.ToString();
                                }

                                string ChequeNo = "";
                                if (dgvTransactions.Rows[x].Cells[2].Value != null)
                                {
                                    ChequeNo = dgvTransactions.Rows[x].Cells[2].Value.ToString();
                                }

                                string ReferenceNo = "";
                                if (dgvTransactions.Rows[x].Cells[3].Value != null)
                                {
                                    ReferenceNo = dgvTransactions.Rows[x].Cells[3].Value.ToString();
                                }

                                decimal Debit = 0;
                                if (dgvTransactions.Rows[x].Cells[4].Value != null)
                                {
                                    Debit = Convert.ToDecimal(dgvTransactions.Rows[x].Cells[4].Value.ToString());
                                }

                                decimal Credit = 0;
                                if (dgvTransactions.Rows[x].Cells[5].Value != null)
                                {
                                    Credit = Convert.ToDecimal(dgvTransactions.Rows[x].Cells[5].Value.ToString());
                                }

                                int result = tblTransactionsTableAdapter.InsertTransaction(AccountCode, Voucher, DocumentNo, Date, Debit, Credit,Narration,ChequeNo,ReferenceNo);

                                if (result>0)
                                {
                                    rSuccess++;
                                }
                            }

                            MessageBox.Show(rSuccess.ToString() + " Out Of " + Convert.ToString(dgvTransactions.RowCount - 1) + " Row(s) Added Successfully!", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            btnReset_Click(sender, e);
                            grbSearch.Enabled = true;
                        }
                        else
                        {
                            MessageBox.Show("That Voucher already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    else if (mode == 1)
                    {
                        for (int x = 0; x < dgvTransactions.RowCount - 1; x++)
                        {                          

                                int AccountCode =Convert.ToInt32(dgvTransactions.Rows[x].Cells[0].Value.ToString());
                                
                                string Narration = "";
                                if (dgvTransactions.Rows[x].Cells[1].Value != null)
                                {
                                    Narration = dgvTransactions.Rows[x].Cells[1].Value.ToString();
                                }

                                string ChequeNo = "";
                                if (dgvTransactions.Rows[x].Cells[2].Value != null)
                                {
                                    ChequeNo = dgvTransactions.Rows[x].Cells[2].Value.ToString();
                                }

                                string ReferenceNo = "";
                                if (dgvTransactions.Rows[x].Cells[3].Value != null)
                                {
                                    ReferenceNo = dgvTransactions.Rows[x].Cells[3].Value.ToString();
                                }

                                decimal Debit = 0;
                                if (dgvTransactions.Rows[x].Cells[4].Value != null)
                                {
                                    Debit = Convert.ToDecimal(dgvTransactions.Rows[x].Cells[4].Value.ToString());
                                }

                                decimal Credit = 0;
                                if (dgvTransactions.Rows[x].Cells[5].Value != null)
                                {
                                    Credit = Convert.ToDecimal(dgvTransactions.Rows[x].Cells[5].Value.ToString());
                                }
                            int result = 0;                            
                            
                            bool added = false;

                            if (dgvTransactions.Rows[x].Cells[6].Value != null)
                            {
                                int rID = Convert.ToInt32(dgvTransactions.Rows[x].Cells[6].Value.ToString());
                                result = tblTransactionsTableAdapter.UpdateTransaction(AccountCode,Voucher,DocumentNo,Date,Debit,Credit,Narration,ChequeNo,ReferenceNo,rID);
                                added = false;
                            }
                            else
                            {
                                result = tblTransactionsTableAdapter.InsertTransaction(AccountCode, Voucher, DocumentNo, Date, Debit, Credit,Narration,ChequeNo,ReferenceNo);
                                added = true;
                            }

                            if (result>0)
                            {
                                if (!added)
                                {
                                    rSuccess++;
                                }
                                else
                                {
                                    rAdded++;
                                }
                            }
                        }
                        string msg = rSuccess.ToString() + " Out Of " + Convert.ToString(dgvTransactions.RowCount - 1 - rAdded) + " Record(s) Updated Successfully!";

                        if (rAdded != 0)
                        {
                            msg += "\n\n" + rAdded.ToString() + " new Records added!";
                        }

                        MessageBox.Show(msg, "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        grbSearch.Enabled = true;
                        mode = 0;
                        btnCloseView.Visible = false;
                        btnLoad.Visible = false;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;
                        btnEdit.Visible = false;
                        btnDelete.Visible = false;

                        this.AcceptButton = btnEdit;

                        dgvTransactions.ReadOnly = true;
                        dgvTransactions.AllowUserToDeleteRows = false;
                       
                        dtpDate.Enabled = true;
                        cmbVoucherType.Enabled = true;                        
                        btnReset_Click(sender, e);
                        txtDocumentNo.ReadOnly = false;
                    }
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid values in their respective format!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            if (exit == 1)
            {
                btnSave.Show();
                btnReset.Show();
                exit = 0;
                dgvVouchers.Hide();                
            }
            else
               this.Close();
        }

        private void frmHallBoking_Load(object sender, EventArgs e)
        {
            this.tblTransactionsTableAdapter.Fill(this.dataSet.tblTransactions);
            // TODO: This line of code loads data into the 'dataSet.tblVouchers' table. You can move, or remove it, as needed.
            this.tblVouchersTableAdapter.Fill(this.dataSet.tblVouchers);
            // TODO: This line of code loads data into the 'dataSet.tblAccounts' table. You can move, or remove it, as needed.
            this.tblAccountsTableAdapter.Fill(this.dataSet.tblAccounts);
            if (DBLayer.User_Right(UserID, SecurityLevelID, "[Write]"))
                btnSave.Enabled = true;
            else
                btnSave.Enabled = false;
            btnReset_Click(sender, e);

            fillGrid();           
        }

        private void txtSerialNo_Leave(object sender, EventArgs e)
        {
            if (txtDocumentNo.Text != "")
            {
                try
                {
                    int serial = Convert.ToInt32(txtDocumentNo.Text);
                    txtDocumentNo.Text = serial.ToString("00000");

                    if (checkDocumentNo(serial,cmbVoucherType.SelectedValue.ToString()))
                    {
                        btnLoad.Visible = true;
                    }
                    else
                    {
                        btnLoad.Visible = false;
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please enter numeric value!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                    txtDocumentNo.Focus();
                }                
            }
            else
            {
                txtDocumentNo.Text = getNextSerialNo().ToString("00000");
            }

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            int DocumentNo = Convert.ToInt32(txtDocumentNo.Text);

            if (checkDocumentNo(DocumentNo,cmbVoucherType.SelectedValue.ToString()))
            {
                //mode = 2;

                SqlConnection Conn = new SqlConnection(con_String);

                try
                {
                    Conn.Open();

                    SqlCommand Command = new SqlCommand("SELECT Voucher, DocumentNo, Dated,AccountCode,  Narration, ChequeNo, ReferenceNo,Debit, Credit,tblTransactions.ID FROM tblTransactions Where Voucher='" + cmbVoucherType.SelectedValue.ToString() + "' and DocumentNo=" + DocumentNo.ToString(), Conn);

                    SqlDataReader Reader = Command.ExecuteReader();

                    if (Reader.HasRows)
                    {
                        txtDocumentNo.ReadOnly = true;

                        if (dgvTransactions.RowCount != 0)
                        {
                            dgvTransactions.Rows.Clear();
                        }
                        
                        btnLoad.Visible = false;
                        btnCloseView.Visible = true;
                        btnSave.Enabled = false;
                        btnReset.Enabled = false;
                        btnEdit.Show();
                        btnDelete.Show();
                        if (DBLayer.User_Right(UserID, SecurityLevelID, "[Modify]"))
                            btnEdit.Enabled = true;
                        else
                            btnEdit.Enabled = false;

                        if (DBLayer.User_Right(UserID, SecurityLevelID, "[Delete]"))
                            btnDelete.Enabled = true;
                        else
                            btnDelete.Enabled = false;

                        dgvTransactions.ReadOnly = true;
                        dgvTransactions.AllowUserToDeleteRows = false;
                        dgvTransactions.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                        grbSearch.Enabled = false;


                        dtpDate.Enabled = false;
                        cmbVoucherType.Enabled = false;

                        while (Reader.Read())
                        {
                            dtpDate.Text = Reader.GetValue(2).ToString();
                            int z = dgvTransactions.Rows.Add();                            
                            
                            for (int x = 3; x < Reader.FieldCount; x++)
                            {
                                string value = Reader.GetValue(x).ToString();

                                string vartype =Reader.GetFieldType(x).ToString();

                                vartype = vartype.Replace("System.", "");
                                
                                if (vartype == "Int32")
                                {
                                    dgvTransactions.Rows[z].Cells[x - 3].Value = Convert.ToInt32(value);
                                }
                                else
                                {
                                    dgvTransactions.Rows[z].Cells[x - 3].Value = value;
                                }
                                
                            }

                        }
                    }

                    Reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                finally
                {
                    if (Conn.State != ConnectionState.Closed || Conn.State != ConnectionState.Broken)
                    {
                        Conn.Close();
                    }

                }
            }

        }

        private void txtSerialNo_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int serial = Convert.ToInt32(txtDocumentNo.Text);
                if (cmbVoucherType.SelectedValue != null)
                {
                    if (checkDocumentNo(serial, cmbVoucherType.SelectedValue.ToString()))
                    {
                        btnLoad.Visible = true;
                        this.AcceptButton = btnLoad;
                    }
                    else
                    {
                        btnLoad.Visible = false;
                        this.AcceptButton = btnSave;
                    }
                }
            }
            catch (FormatException)
            {

            }
        }

        private void btnCloseView_Click(object sender, EventArgs e)
        {
            txtDocumentNo.ReadOnly = false;           
            mode = 0;
            btnCloseView.Visible = false;

            if (DBLayer.User_Right(UserID, SecurityLevelID, "[Write]"))
                btnSave.Enabled = true;
            else
                btnSave.Enabled = false;

            btnReset.Enabled = true;
            btnEdit.Visible = false;
            this.AcceptButton = btnSave;
            dgvTransactions.ReadOnly = false;
            dgvTransactions.AllowUserToDeleteRows = true;
            dtpDate.Enabled = true;
            cmbVoucherType.Enabled = true;
            btnDelete.Visible = false;
            btnReset_Click(sender, e);
            grbSearch.Enabled = true;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            btnEdit.Visible = false;
            mode = 1;
            dgvTransactions.ReadOnly = false;
            dgvTransactions.AllowUserToDeleteRows = true;
            btnSave.Enabled = true;
            dtpDate.Enabled = true;
            cmbVoucherType.Enabled = true;
            btnDelete.Visible = false;
            dgvTransactions.SelectionMode = DataGridViewSelectionMode.RowHeaderSelect;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete?\n\nThis will remove all records in current booking!", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    int result2 = tblTransactionsTableAdapter.DeleteTransactions(cmbVoucherType.SelectedValue.ToString(), Convert.ToInt32(txtDocumentNo.Text));
                    if(result2>0)
                    {
                        MessageBox.Show("Successfully deleted!");
                        btnCloseView_Click(sender,e);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message , "Error" , MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
        }

        private void dgvHallBooking_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            try
            {
                if (e.Row.Cells[6].Value != null && mode == 1)
                {
                    if (dgvTransactions.Rows.Count== 2)
                    {
                        e.Cancel = true;
                        btnDelete_Click(sender, e);
                    }
                    else
                    {
                        DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (result == DialogResult.Yes)
                        {
                            int result2 = tblTransactionsTableAdapter.DeleteTransaction(Convert.ToInt32(e.Row.Cells[6].Value.ToString()));
                            if (result2>0)
                            {
                                MessageBox.Show("Successfully deleted!");

                                //dgvHallBooking.Rows.Add(1);

                            }
                        }
                        else
                        {
                            e.Cancel = true;
                        }
                        
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message , "Error" , MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }            
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string[] serial = getVoucherByDate(Convert.ToDateTime(dtpSearchDate.Text));
            
            if (serial[0] != null && serial[1]!= null)
            {
                //btnCloseView_Click(sender,e);

                int seriaL = Convert.ToInt32(serial[1]);
                
                txtDocumentNo.Text = seriaL.ToString("00000");
                
                cmbVoucherType.SelectedText = serial[0];

                //btnLoad_Click(sender, e);
                dgvVouchers.Show();
                dgvVouchers.BringToFront();
                btnSave.Hide();
                btnReset.Hide();
                btnLoad.Hide();
                exit = 1;               
            }
            
            else
            {
                MessageBox.Show("No Transaction Found on the date provided.", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void dgvVouchers_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string[] serial = dgvVouchers.CurrentRow.Cells[0].Value.ToString().Split(Convert.ToChar("-"));
            txtDocumentNo.Text = serial[1].ToString();
            cmbVoucherType.Text = serial[0].ToString();
            btnLoad_Click(sender, e);
            dgvVouchers.Hide();
            btnSave.Show();
            btnReset.Show();
            

        }

        private void cmbVoucherType_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtSerialNo_TextChanged(sender, e);
        }
      
    }
}   
    
