using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MCKJ
{
    public partial class frmHeaderType : Form
    {
        int mode = 0;
        int ID = 0;
        string FHeader = "Header Type";
        public string con_String = Community.DBLayer.con_String;

        public frmHeaderType()
        {
            InitializeComponent();
        }

        private void frmHeaderType_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'comDataSet.tblAccounts' table. You can move, or remove it, as needed.
            this.tblAccountsTableAdapter.Fill(this.comDataSet.tblAccounts);
            // TODO: This line of code loads data into the 'dataset2.tblHeaderType' table. You can move, or remove it, as needed.
            this.tblHeaderTypeTableAdapter.Fill(this.dataset2.tblHeaderType);
            // TODO: This line of code loads data into the 'dataset2.tblHeader' table. You can move, or remove it, as needed.
            this.tblHeaderTableAdapter.Fill(this.dataset2.tblHeader);
            // TODO: This line of code loads data into the 'dataset.tblHeader' table. You can move, or remove it, as needed.
           
            // TODO: This line of code loads data into the 'dataset.tblHeaderType' table. You can move, or remove it, as needed.            
            dgvHeaderType.BringToFront();
        }

        public void EnableDisable(bool character)
        {
            txtCode.Enabled = character;
            txtHeaderType.Enabled = character;
            cmbHeader.Enabled = character;
            btnAdd.Enabled = !character;
            btnEdit.Enabled = !character;
            btnDelete.Enabled = !character;
            dgvHeaderType.Visible = !character;
        }

        private bool Check_code(string code,int Header)
        {
            bool result = false;
            SqlConnection Conn = null;
            try
            {
                Conn = new SqlConnection(con_String);
                Conn.Close();
                Conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Code FROM tblSubHeader WHERE Code = '" + code + "' AND Header = "+Header , Conn);
                cmd.CommandType = CommandType.Text;

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    MessageBox.Show("Code already exist!", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cmbHeader.Focus();
                    return true;
                }
                else
                    return false;

                Conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return true;
            }
        }


        public void Clearfields()
        {
            txtCode.Text = "";
            txtHeaderType.Text = "";
            cmbHeader.Text = "";
        }

        public bool CheckField()
        {
            if (txtCode.Text == "" || txtHeaderType.Text == "" || cmbHeader.Text == "")
            {
                MessageBox.Show("Fields Cannot Left Blanks!!","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
  
        private void btnAdd_Click(object sender, EventArgs e)
        {
            mode = 1;
            EnableDisable(true);
            Clearfields();
            Text = FHeader + " >> Adding Header Type";            
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            mode = 0;
            if (dgvHeaderType.Rows.Count != 0)
            {
                ID = Convert.ToInt32(dgvHeaderType.CurrentRow.Cells[0].Value.ToString());
                EnableDisable(true);
                txtCode.Enabled = false;
                Text = FHeader + " >> Updating Header Type";
            
            }
            else
            {
                MessageBox.Show("No record for Edit!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);  
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvHeaderType.Rows.Count != 0)
            {
                ID = Convert.ToInt32(dgvHeaderType.CurrentRow.Cells[0].Value.ToString());
                string[] table = { "tblAccounts" };
                string[] field = { "AccType" };
                if (!frmAccounts.check_Other(table,field,ID.ToString()))
                {
                    Text = FHeader + " >> Deleting Header Type";
                    DialogResult result = MessageBox.Show("Are you sure you want to Delete?", "Cofirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        tblHeaderTypeTableAdapter.DeleteQuery(ID);
                        MessageBox.Show("Deleted Succesfully!!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        tblHeaderTypeTableAdapter.Fill(dataset2.tblHeaderType);
                        Text = FHeader;

                    }
                    else
                        Text = FHeader;
                }
                else
                {
                    MessageBox.Show("Sub header already in use...\nCannot be deleted", "Cannot delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
                MessageBox.Show("No record for delete!", "No record", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            EnableDisable(false);
            tblHeaderTypeTableAdapter.Fill(dataset2.tblHeaderType);
            Text = FHeader;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string code = txtCode.Text;
                int Header = Convert.ToInt32(cmbHeader.SelectedValue.ToString());
                string acccode = textBox1.Text + "-" + code;
                if (CheckField() && !Check_code(code,Header))
                {                    
                    string HeaderType = txtHeaderType.Text;
                    
                    if (mode == 1)
                    {
                        
                        tblHeaderTypeTableAdapter.InsertQuery(code, HeaderType, Header);
                        MessageBox.Show("Saved Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        tblAccountsTableAdapter.InsertAccount(acccode, HeaderType, "", "", "", "", "", "", "", "", "", "", "", 0, 0, "", "", "");
                        EnableDisable(false);
                        tblHeaderTypeTableAdapter.Fill(dataset2.tblHeaderType);                        
                        Text = FHeader;
                    }
                    else
                    {
                       
                        tblHeaderTypeTableAdapter.UpdateQuery(code, HeaderType, Header,ID);
                        MessageBox.Show("Saved Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        EnableDisable(false);
                        tblHeaderTypeTableAdapter.Fill(dataset2.tblHeaderType);
                        Text = FHeader;
                        txtCode.Enabled = true;
                    }
                }
            }

            catch (FormatException)
            {
                MessageBox.Show("Please enter valid values in respective fields!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception exceptionparameter)
            {
                MessageBox.Show(exceptionparameter.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } 
        }

        private void txtCode_Leave(object sender, EventArgs e)
        {
            if (txtCode.Text != "" && dgvHeaderType.Visible == false && mode != 0)
            {
                if (txtCode.Text == "0" || txtCode.Text == "00")
                {
                    string cod = txtCode.Text;
                    string msg = "You cannot enter Code '%00%'\nPlease enter from 01 to 99";
                    msg = msg.Replace("%00%", cod);
                    MessageBox.Show(msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCode.Focus();
                }                
            }
        }
       
    }
}